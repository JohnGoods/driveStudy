
#ifndef __YAWL_H
#define __YAWL_H
//#lib /ucw/lib/yawl.dll
#lib yawl.dll
#include "..\use\twl.h"
#include "..\use\twl_data.h"
#include "..\use\twl_cntrls.h"
#include "..\use\twl_layout.h"
#include "..\use\twl_ini.h"
#include "..\use\twl_menu.h"
#include "..\use\twl_automenu.h"
#include "..\use\twl_dialogs.h"
#include "..\use\twl_modal.h"
#include "..\use\twl_toolbar.h"
#include "..\use\twl_splitter.h"
#include "..\use\twl_imagelist.h"
#include "..\use\twl_tab.h"
#include "..\use\twl_listview.h"
#include "..\use\twl_treeview.h"
#lib
#endif

