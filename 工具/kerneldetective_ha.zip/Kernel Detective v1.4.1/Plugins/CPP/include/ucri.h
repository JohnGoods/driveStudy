// UCRI.H
// Reflection Interface for UnderC.
// Please note the location of the actual header,
// which is shared with the UC code base.
// UnderC Development Project, 2001-2002
#ifndef __UCRI_INC_H
#define __UCRI_INC_H
#ifdef __MS_BUILT
#lib $self
#else
#lib $self self.imp
#endif
#include "..\src\ucri.h"
#lib
#endif
