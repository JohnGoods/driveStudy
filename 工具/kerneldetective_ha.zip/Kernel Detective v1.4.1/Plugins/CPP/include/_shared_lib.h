// _shared_lib.h
// UnderC Pocket C++ Library, Steve Donovan 2001.
#lib msvcrt40.dll