/* gdk.h 
 * Fake header for GTK+ inports
*/
