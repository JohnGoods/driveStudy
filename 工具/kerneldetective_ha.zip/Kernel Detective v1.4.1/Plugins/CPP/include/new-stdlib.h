// UnderC Development Project, 2001
#ifndef __STDLIB_H
#define __STDLIB_H
#include <_shared_lib.h>
extern "C" {
  char *getenv(char *);
}
#include <_end_shared.h>

#endif