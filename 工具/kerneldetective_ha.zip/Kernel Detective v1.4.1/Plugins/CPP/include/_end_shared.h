// Used to end a set of declarations involving a shared library
// I've put this in its own header (see <_begin_shared.h>) since
// we will probably change this to a special #pragma
#lib
