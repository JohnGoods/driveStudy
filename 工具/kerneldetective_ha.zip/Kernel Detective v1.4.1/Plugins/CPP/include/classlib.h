// UnderC Development Project, 2001
// standard library includes (default)
#define __UC__
#include <iostream>
#include <string>
#ifndef _CONSOLE
#include <sstream>
#endif

#include <list>
#include <vector>
#include <map>
#include <algorithm>
#include <uc_except.h>

