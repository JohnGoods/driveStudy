#ifndef _KDP_H
#define _KDP_H

#pragma once
#include <windows.h>
#pragma pack(1)            // Force byte alignment of structures


#define WINAPI              __stdcall
#define STRING_LENGTH       260
#define NULL                0
#define FALSE               0
#define TRUE                1


typedef float               FLOAT;
typedef FLOAT               *PFLOAT;
typedef BOOL                *PBOOL, *LPBOOL; 
typedef int                 *PINT, *LPINT;
typedef unsigned char       BYTE;
typedef BYTE                *PBYTE, *LPBYTE;
typedef BYTE                BOOLEAN;
typedef BOOLEAN             *PBOOLEAN;
typedef WORD                *PWORD, *LPWORD;
typedef void                VOID;
typedef VOID                *LPVOID;
typedef VOID                *HANDLE;
typedef char                CHAR, *PCHAR;
typedef unsigned char       UCHAR, *PUCHAR;
typedef short               SHORT, *PSHORT;
typedef unsigned short      USHORT, *PUSHORT;
typedef long                LONG, *PLONG;
typedef unsigned long       ULONG, *PULONG;
typedef unsigned long       ULONG_PTR, *PULONG_PTR;
typedef ULONG_PTR           SIZE_T, *PSIZE_T;



typedef VOID (*PKSTART_ROUTINE)(PVOID StartContext);

typedef struct LONGLONG {
    ULONG LowPart;
    LONG  HighPart;
};
typedef LONGLONG LARGE_INTEGER, *PLARGE_INTEGER, *PLONGLONG;


typedef struct ULONGLONG {
    ULONG LowPart;
    ULONG HighPart;
};
typedef ULONGLONG ULARGE_INTEGER, *PULARGE_INTEGER, *PULONGLONG;


typedef struct PROCESS_ENTRY {
    ULONG ProcessObject;
    ULONG ImageBase;
    ULONG Peb;
    ULONG ProcessId;
    ULONG ParentId;
    ULONG VirtualSize;
    CHAR Path[STRING_LENGTH];
};
typedef PROCESS_ENTRY *PPROCESS_ENTRY;


typedef struct DLL_ENTRY {
    ULONG BaseAddress;
    ULONG EntryPoint;
    ULONG SizeOfImage;
    CHAR FullDllName[STRING_LENGTH];
};
typedef DLL_ENTRY *PDLL_ENTRY;


typedef struct DRIVER_ENTRY {
    ULONG ImageBase;
    ULONG EntryPoint;
    ULONG ImageSize;
    CHAR ImagePath[STRING_LENGTH];
};
typedef DRIVER_ENTRY *PDRIVER_ENTRY;


typedef struct HANDLE_ENTRY {
    ULONG ProcessObject;
    ULONG UniqueProcessId;
    ULONG Handle;
    ULONG Object;
	ULONG ObjectType;
    ULONG GrantedAccess;
    ULONG HandleCount;
    CHAR ObjectName[STRING_LENGTH];
};
typedef HANDLE_ENTRY *PHANDLE_ENTRY;


typedef struct OBJECT_TYPE_ENTRY {
    ULONG Address;
    ULONG Count;
    ULONG Index;
    ULONG DumpProcedure;
    ULONG OpenProcedure;
    ULONG CloseProcedure;
    ULONG DeleteProcedure;
    ULONG ParseProcedure;
    ULONG SecurityProcedure;
    ULONG QueryNameProcedure;
    ULONG OkayToCloseProcedure;
    CHAR ObjectTypeName[STRING_LENGTH];
};
typedef OBJECT_TYPE_ENTRY *POBJECT_TYPE_ENTRY;


typedef struct THREAD_ENTRY {
    ULONG ProcessObject;
    ULONG ProcessId;
    ULONG ThreadObject;
    ULONG ThreadId;
    ULONG Teb;
    ULONG ServiceTable;
    ULONG StartAddress;
};
typedef THREAD_ENTRY *PTHREAD_ENTRY;


typedef struct SERVICE_ENTRY {
    ULONG Index;
    ULONG Current;
    ULONG Original;
};
typedef SERVICE_ENTRY *PSERVICE_ENTRY;


typedef struct LIST_ENTRY {
   struct LIST_ENTRY *Flink;
   struct LIST_ENTRY *Blink;
};
typedef LIST_ENTRY *PLIST_ENTRY;


typedef struct DISPATCHER_HEADER {
    UCHAR Type;
    UCHAR Absolute;
    UCHAR Size;
    UCHAR Inserted;
    LONG SignalState;
    LIST_ENTRY WaitListHead;
};


typedef struct KDPC {
    SHORT Type;
    UCHAR Number;
    UCHAR Importance;
    LIST_ENTRY DpcListEntry;
    PVOID DeferredRoutine;
    PVOID DeferredContext;
    PVOID SystemArgument1;
    PVOID SystemArgument2;
    PULONG_PTR Lock;
};


typedef struct KTIMER {
    DISPATCHER_HEADER Header;
    ULARGE_INTEGER DueTime;
    LIST_ENTRY TimerListEntry;
    struct _KDPC *Dpc;
    LONG Period;
};


typedef struct TIMER_ENTRY {
    ULONG Object;
    ULONG Thread;
    KTIMER Timer;
    KDPC Dpc;
};
typedef TIMER_ENTRY *PTIMER_ENTRY;


typedef struct KIDT_ENTRY {
    USHORT Offset;
    USHORT Selector;
    USHORT Access;
    USHORT ExtendedOffset;
};
typedef KIDT_ENTRY *PKIDT_ENTRY;


typedef struct BIOS_REGISTERS {
    ULONG Eax;
    ULONG Ecx;
    ULONG Edx;
    ULONG Ebx;
    ULONG Ebp;
    ULONG Esi;
    ULONG Edi;
    USHORT SegDs;
    USHORT SegEs;
    ULONG EFlags;
};
typedef BIOS_REGISTERS *PBIOS_REGISTERS;

typedef struct FLOATING_SAVE_AREA {
    DWORD   ControlWord;
    DWORD   StatusWord;
    DWORD   TagWord;
    DWORD   ErrorOffset;
    DWORD   ErrorSelector;
    DWORD   DataOffset;
    DWORD   DataSelector;
    BYTE    RegisterArea[80];
    DWORD   Cr0NpxState;
};
typedef FLOATING_SAVE_AREA *PFLOATING_SAVE_AREA;


typedef struct CONTEXT {
    DWORD ContextFlags;
    DWORD   Dr0;
    DWORD   Dr1;
    DWORD   Dr2;
    DWORD   Dr3;
    DWORD   Dr6;
    DWORD   Dr7;
    FLOATING_SAVE_AREA FloatSave;
    DWORD   SegGs;
    DWORD   SegFs;
    DWORD   SegEs;
    DWORD   SegDs;
    DWORD   Edi;
    DWORD   Esi;
    DWORD   Ebx;
    DWORD   Edx;
    DWORD   Ecx;
    DWORD   Eax;
    DWORD   Ebp;
    DWORD   Eip;
    DWORD   SegCs;
    DWORD   EFlags;
    DWORD   Esp;
    DWORD   SegSs;
    BYTE    ExtendedRegisters[512];
};
typedef CONTEXT *PCONTEXT;


typedef struct MEMORY_BASIC_INFORMATION {
    PVOID BaseAddress;
    PVOID AllocationBase;
    DWORD AllocationProtect;
    SIZE_T RegionSize;
    DWORD State;
    DWORD Protect;
    DWORD Type;
};
typedef MEMORY_BASIC_INFORMATION *PMEMORY_BASIC_INFORMATION;




#endif